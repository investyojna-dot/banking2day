/* ============================================================
   Banking2Day — Django REST data layer (drop-in for b2d-cms.js)
   ------------------------------------------------------------
   Load on every page:
     <script src="b2d-api.js"></script>
   Then call window.B2D.*  exactly like the Supabase version.
   Set API_BASE below to your deployed Django URL.
   ============================================================ */
(function () {
  if (window.B2D) return;

  // ---- CONFIG : your Django backend base URL (no trailing slash) ----
  const API_BASE = "http://localhost:8000/api";
  // e.g. production:  const API_BASE = "https://api.banking2day.com/api";
  // -------------------------------------------------------------------

  const CONFIGURED = API_BASE.indexOf("localhost") === -1;
  const tokenKey = "b2d_admin_token";
  const getToken = () => { try { return localStorage.getItem(tokenKey); } catch (_) { return null; } };

  // build a query string from defined params, e.g. {category:"x"} -> "?category=x"
  function qs(params) {
    const parts = Object.keys(params)
      .filter(k => params[k] !== undefined && params[k] !== null && params[k] !== "")
      .map(k => encodeURIComponent(k) + "=" + encodeURIComponent(params[k]));
    return parts.length ? "?" + parts.join("&") : "";
  }

  function headers(json) {
    const h = {};
    if (json) h["Content-Type"] = "application/json";
    const t = getToken();
    if (t) h["Authorization"] = "Token " + t;
    return h;
  }

  async function req(method, path, body) {    const res = await fetch(API_BASE + path, {
      method,
      headers: headers(body !== undefined),
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
    if (!res.ok) throw new Error("API " + res.status + " on " + path);
    if (res.status === 204) return null;
    return res.json();
  }

  const B2D = {
    configured: CONFIGURED,

    /* ---------- AUTH ---------- */
    async login(username, password) {
      const data = await req("POST", "/login/", { username, password });
      try { localStorage.setItem(tokenKey, data.token); } catch (_) {}
      return data;
    },
    async logout() { try { localStorage.removeItem(tokenKey); } catch (_) {} },
    async currentUser() { return getToken() ? { token: getToken() } : null; },

    /* ---------- PRODUCTS ---------- */
    getProducts: (category, platform) => req("GET", "/products/" + qs({ category, platform })),
    saveProduct: (row) => row.id ? req("PUT", `/products/${row.id}/`, row) : req("POST", "/products/", row),
    deleteProduct: (id) => req("DELETE", `/products/${id}/`),
    setProductStatus: (id, status) => req("PATCH", `/products/${id}/`, { status }),

    /* ---------- ARTICLES ---------- */
    getArticles: (opts = {}) => req("GET", "/articles/" + qs({ status: opts.status, platform: opts.platform })),
    saveArticle: (row) => row.id ? req("PUT", `/articles/${row.id}/`, row) : req("POST", "/articles/", row),
    deleteArticle: (id) => req("DELETE", `/articles/${id}/`),

    /* ---------- PROMOTIONS ---------- */
    getPromotions: (onlyEnabled, platform) => req("GET", "/promotions/" + qs({ enabled: onlyEnabled ? "true" : undefined, platform })),
    savePromotion: (row) => row.id ? req("PATCH", `/promotions/${row.id}/`, row) : req("POST", "/promotions/", row),
    deletePromotion: (id) => req("DELETE", `/promotions/${id}/`),

    /* ---------- LEADS ---------- */
    submitLead: (row) => req("POST", "/leads/", row),
    getLeads: () => req("GET", "/leads/"),
    setLeadStatus: (id, status) => req("PATCH", `/leads/${id}/`, { status }),

    /* ---------- SUBSCRIBERS ---------- */
    subscribe: (email, source = "footer") => req("POST", "/subscribers/", { email, source, status: "Subscribed" }),
    getSubscribers: () => req("GET", "/subscribers/"),
    setSubscriberStatus: (id, status) => req("PATCH", `/subscribers/${id}/`, { status }),

    /* ---------- CREDIT CHECKS ---------- */
    submitCreditCheck: (row) => req("POST", "/credit-checks/", row),
    getCreditChecks: () => req("GET", "/credit-checks/"),
    setCreditCheckStatus: (id, status) => req("PATCH", `/credit-checks/${id}/`, { status }),

    /* ---------- SITE SETTINGS ---------- */
    getSettings: () => req("GET", "/settings/"),
    setSetting: (key, enabled) => req("PATCH", `/settings/${key}/`, { enabled }),

    /* ---------- CALCULATOR DEFAULTS ---------- */
    getCalcDefaults: () => req("GET", "/calculator-defaults/"),
    getCalcDefault: (key) => req("GET", `/calculator-defaults/${key}/`),
    saveCalcDefault: (row) => req("PUT", `/calculator-defaults/${row.key}/`, row),
  };

  window.B2D = B2D;
  console.log("[B2D] Django data layer ready");
})();
