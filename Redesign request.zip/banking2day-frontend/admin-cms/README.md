# Banking2Day — Django REST Backend

A complete Python/Django backend for the Banking2Day website: a database, a REST API the
site calls, a ready-made admin UI, and token-based admin login. This replaces the Supabase
backend for teams that prefer Django.

## What's inside

```
banking2day-backend/
├── manage.py
├── requirements.txt
├── .env.example
├── b2d-api.js                ← frontend data layer (use INSTEAD of admin-cms/b2d-cms.js)
├── banking2day/              ← project config (settings, urls, wsgi/asgi)
└── core/                     ← the app
    ├── models.py             ← Product, Article, Promotion, Lead, Subscriber,
    │                            CreditCheck, SiteSetting, CalculatorDefault
    ├── serializers.py        ← JSON conversion
    ├── views.py              ← REST API + /api/login/ (token auth)
    ├── urls.py               ← /api/ routes
    ├── admin.py              ← Django admin (content management UI)
    └── management/commands/seed.py   ← starter content
```

## Requirements
- Python 3.10+
- pip (and ideally a virtual environment)

## Setup (local, ~5 minutes)

```bash
cd banking2day-backend

# 1. virtual environment
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 2. install dependencies
pip install -r requirements.txt

# 3. environment file
cp .env.example .env              # then edit if you like; defaults work for local

# 4. create the database tables (SQLite by default — zero config)
python manage.py makemigrations
python manage.py migrate

# 5. load starter content (products, articles, promotions, settings, calculators)
python manage.py seed

# 6. create your admin login
python manage.py createsuperuser  # follow prompts for username + password

# 7. run it
python manage.py runserver
```

Now you have:
- **API** at `http://localhost:8000/api/`  (e.g. `GET /api/products/`)
- **Admin UI** at `http://localhost:8000/admin/`  (log in with the superuser you created)

## How the website talks to it

The frontend uses **`b2d-api.js`** (in this folder) instead of `admin-cms/b2d-cms.js`.
It exposes the exact same `window.B2D.*` functions, so the pages don't change — only the
data layer does.

1. Copy `b2d-api.js` into your site folder (next to the pages).
2. Open it and set `API_BASE` to your backend URL:
   ```js
   const API_BASE = "http://localhost:8000/api";        // local
   // const API_BASE = "https://api.banking2day.com/api"; // production
   ```
3. On each page, replace the two Supabase scripts:
   ```html
   <!-- OLD (Supabase) -->
   <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
   <script src="admin-cms/b2d-cms.js"></script>
   <!-- NEW (Django) -->
   <script src="b2d-api.js"></script>
   ```
   The forms (newsletter, credit-score, loan apply) then save into Django automatically.

## Two ways to manage content

1. **Django admin** (`/admin/`) — full-featured, built in, recommended for staff.
2. **The custom admin panel** (`admin-cms/admin.html`) — also works; point it at this API by
   loading `b2d-api.js` instead of `b2d-cms.js` (it already calls `B2D.login`, `B2D.getProducts`, etc.).

## API reference (all under `/api/`)

| Method | Path | Who | Purpose |
|--------|------|-----|---------|
| POST | `/login/` | public | exchange username+password for a token |
| GET | `/products/?category=personal_loan` | public | live products |
| POST/PUT/DELETE | `/products/` | admin | manage products |
| GET | `/articles/?status=Published` | public | published articles |
| GET | `/promotions/?enabled=true` | public | active promotions |
| POST | `/leads/` | public | submit a loan enquiry |
| GET | `/leads/` | admin | view enquiries |
| POST | `/subscribers/` | public | newsletter sign-up |
| POST | `/credit-checks/` | public | free credit-score sign-up |
| GET | `/settings/`, `/calculator-defaults/` | public | site config |

Writes require the header `Authorization: Token <your-token>` (the data layer adds this
automatically after `B2D.login`).

## Going to production

1. Use **PostgreSQL**: set `DATABASE_URL` in `.env` and install is already handled
   (`psycopg2-binary` is in requirements).
2. Set `DEBUG=False`, a strong `SECRET_KEY`, and your real domain(s) in `ALLOWED_HOSTS`.
3. Set `CORS_ALLOWED_ORIGINS` to your website's URL (e.g. `https://banking2day.pages.dev`).
4. Collect static files: `python manage.py collectstatic`.
5. Run with gunicorn: `gunicorn banking2day.wsgi`.
6. Host on anything that runs Python — **Railway, Render, Fly.io, AWS, DigitalOcean**.
   (The static site can still live on Cloudflare Pages; only this API needs a Python host.)

## Security notes
- Public can only read live content and submit a lead / subscriber / credit-check.
- All editing and reading of leads requires an authenticated admin token.
- Never commit your real `.env` or `SECRET_KEY` to source control.
